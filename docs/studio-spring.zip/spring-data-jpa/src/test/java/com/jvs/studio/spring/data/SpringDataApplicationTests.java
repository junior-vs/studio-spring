package com.jvs.studio.spring.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class SpringDataApplicationTests {

//	@Test
	void contextLoads() {
	}

}
